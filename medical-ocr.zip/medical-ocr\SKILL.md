---
name: medical-ocr
description: |
  医学文档OCR本地化识别技能。当用户需要识别图片、PDF中的医学检查报告、病历资料、体检报告等文字内容时使用。
  触发词包括：OCR识别、扫描识别、文字识别、体检报告识别、病历识别、检查报告OCR、图片转文字、医学文档识别、扫描件识别、PDF文字提取。
  支持本地化部署，不依赖云服务API。
---

# Medical OCR - 医学文档本地化OCR识别

本技能提供完整的本地化OCR识别解决方案，支持图片、PDF文档中的医学检查报告、病历资料、体检报告等文字内容的识别。

## 核心功能

- **图片OCR识别**：支持JPG、PNG、BMP等格式的医学文档图片
- **PDF文档OCR**：支持扫描版PDF和文本PDF的文字提取
- **摄像头拍照识别**：支持实时拍照或已保存的照片进行OCR
- **医学术语优化**：内置医学术语字典，提升识别准确率
- **完全本地化部署**：不依赖任何云服务API，保护隐私安全

## 支持的OCR引擎

### 1. PaddleOCR（推荐）

百度开源的高精度中文OCR引擎，对医学文档识别效果优秀。

**安装依赖：**
```bash
pip install paddlepaddle paddleocr
```

**优势：**
- 中文识别准确率高
- 内置多种语言支持
- 支持表格识别
- 轻量级模型可选

### 2. Tesseract OCR

Google开源OCR引擎，需要额外安装语言包。

**安装依赖：**
```bash
pip install pytesseract
# Windows需要安装Tesseract: https://github.com/UB-Mannheim/tesseract/wiki
# 需要下载中文简体语言包: chi_sim
```

**优势：**
- 开源免费
- 多语言支持丰富
- 社区成熟

### 3. EasyOCR

支持80+语言的通用OCR引擎。

**安装依赖：**
```bash
pip install easyocr
```

**优势：**
- 开源免费
- 多语言同时识别
- 预训练模型丰富

## 使用流程

### Step 1: 环境准备

使用 `scripts/setup_ocr_env.py` 脚本自动安装所需依赖：

```python
# 运行设置脚本
python scripts/setup_ocr_env.py
```

脚本会自动：
- 检测当前系统环境
- 安装Python依赖包
- 下载预训练模型
- 验证OCR功能

### Step 2: OCR识别

根据输入类型选择合适的识别脚本：

**图片识别**（使用 `scripts/ocr_image.py`）：
```python
from scripts.ocr_image import OCRProcessor

processor = OCRProcessor(engine='paddleocr')
result = processor.recognize('medical_report.jpg')
print(result.text)
```

**PDF识别**（使用 `scripts/ocr_pdf.py`）：
```python
from scripts.ocr_pdf import PDFOCRProcessor

processor = PDFOCRProcessor(engine='paddleocr')
result = processor.recognize('medical_report.pdf')
print(result.text)
```

### Step 3: 后处理

识别结果可通过 `scripts/post_process.py` 进行优化：

- 医学术语校正
- 格式规范化
- 结构化提取（表格、列表等）

## 脚本说明

### scripts/ocr_image.py
图片OCR识别主程序，支持多种OCR引擎。

核心类：`OCRProcessor`
- `__init__(engine='paddleocr', lang='ch')`: 初始化处理器
- `recognize(image_path, with_confidence=False)`: 识别图片
- `recognize_batch(image_paths)`: 批量识别

### scripts/ocr_pdf.py
PDF文档OCR识别，支持扫描版和文本PDF。

核心类：`PDFOCRProcessor`
- `__init__(engine='paddleocr')`: 初始化处理器
- `extract_text(pdf_path)`: 提取文本
- `extract_tables(pdf_path)`: 提取表格
- `convert_to_images(pdf_path)`: PDF转图片

### scripts/ocr_camera.py
摄像头/拍照OCR识别，支持实时处理。

核心类：`CameraOCR`
- `capture_and_recognize()`: 拍照并识别
- `recognize_from_file(image_path)`: 识别已有图片

### scripts/setup_ocr_env.py
环境自动配置脚本，检测并安装所需依赖。

### scripts/medical_terms.py
医学术语工具，提供术语标准化和校验功能。

## 医学文档识别最佳实践

### 1. 图片质量要求
- 分辨率建议：300 DPI以上
- 光照均匀，避免阴影
- 文字清晰，无模糊
- 尽量保持文档平整

### 2. 常见医学文档类型
- **体检报告**：血常规、尿常规、生化检查等
- **病历资料**：入院记录、出院小结、手术记录等
- **检查报告**：影像报告、超声报告、心电图等
- **处方单**：药品名称、剂量、用法等

### 3. 识别后校验
- 核对关键数值（血糖、血压等）
- 检查日期和个人信息
- 确认医生签名和医院印章

## 隐私安全

本技能所有OCR处理均在本地完成：
- 不上传任何图片或文档到外部服务器
- 不使用云端OCR API
- 数据完全在本地环境处理
- 适合医疗数据保密要求

## 故障排除

### 问题1：PaddleOCR模型下载失败
```
解决方案：手动下载模型并放置到正确目录
模型地址：https://paddleocr.bj.bcebos.com/dygraph_v2.0/ch/ch_pp-ocrv3_det_infer.tar
```

### 问题2：Tesseract中文识别不准
```
解决方案：
1. 确保安装了 chi_sim 和 chi_tra 语言包
2. 使用 --oem 3 --psm 6 参数优化
3. 考虑使用PaddleOCR替代
```

### 问题3：PDF转图片质量差
```
解决方案：
1. 使用较高DPI（如300）
2. 安装Ghostscript改善PDF渲染
3. 检查原始PDF是否为扫描件
```

## 参考资料

详细OCR引擎对比和医学术语表请参阅：
- `references/ocr_engines_comparison.md` - OCR引擎对比分析
- `references/medical_terms_glossary.md` - 医学术语词汇表
